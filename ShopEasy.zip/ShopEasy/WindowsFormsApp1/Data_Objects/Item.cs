using System;

namespace ShopEasy
{

    public class Item
    {

    public string Name{
	        get;
            set;
	}
	
	public int ID{
            get;
            set;
	}

    }

}
