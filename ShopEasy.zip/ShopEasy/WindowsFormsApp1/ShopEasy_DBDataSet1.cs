﻿namespace ShopEasy
{


    partial class ShopEasy_DBDataSet
    {
    }
}

namespace ShopEasy.ShopEasy_DBDataSetTableAdapters
{


    public partial class Invoices_DetailTableAdapter
    {
    }
}
