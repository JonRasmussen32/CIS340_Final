﻿Select *
from Person where PerID = 1